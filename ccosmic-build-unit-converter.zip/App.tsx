import React from 'react';
import Header from './components/Header';
import Calculator from './components/Calculator';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#FDFBF5] text-[#2D2D2D] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md mx-auto">
        <Header />
        <main>
          <Calculator />
        </main>
      </div>
       <footer className="text-center mt-8 text-xs text-gray-500">
        <p>Conversion rates derived from the provided chart data.</p>
        <p>This is a recreational tool for demonstration purposes.</p>
      </footer>
    </div>
  );
};

export default App;
