import React, { useState } from 'react';
import { InputName, type ConversionState } from '../types';
import { UNITS_TO_GRAMS_SOLO_FACTOR, PLASTIC_WEIGHT_GRAMS } from '../constants';
import InputGroup from './InputGroup';

const Calculator: React.FC = () => {
  const [values, setValues] = useState<ConversionState>({
    units: '',
    solo: '',
    plastic: '',
  });

  const handleInputChange = (name: InputName, value: string) => {
    if (value === '') {
      setValues({ units: '', solo: '', plastic: '' });
      return;
    }

    const numericValue = parseFloat(value);

    if (isNaN(numericValue) || numericValue < 0) {
      // Allow typing of non-numeric characters but don't calculate
      // Reset other fields to avoid confusion with stale data
      setValues({
        units: name === InputName.Units ? value : '',
        solo: name === InputName.Solo ? value : '',
        plastic: name === InputName.Plastic ? value : '',
      });
      return;
    }

    let newValues: ConversionState = { units: '', solo: '', plastic: '' };

    switch (name) {
      case InputName.Units:
        const u = numericValue;
        const sFromU = u * UNITS_TO_GRAMS_SOLO_FACTOR;
        const pFromU = sFromU + PLASTIC_WEIGHT_GRAMS;
        newValues = {
          units: value,
          solo: sFromU.toFixed(3),
          plastic: pFromU.toFixed(3),
        };
        break;

      case InputName.Solo:
        const s = numericValue;
        const uFromS = s / UNITS_TO_GRAMS_SOLO_FACTOR;
        const pFromS = s + PLASTIC_WEIGHT_GRAMS;
        newValues = {
          units: uFromS.toFixed(2),
          solo: value,
          plastic: pFromS.toFixed(3),
        };
        break;

      case InputName.Plastic:
        const p = numericValue;
        const sFromP = p - PLASTIC_WEIGHT_GRAMS;
        if (sFromP < 0) {
          // If plastic weight is less than plastic itself, result is invalid
          setValues({ units: 'N/A', solo: 'N/A', plastic: value });
          return;
        }
        const uFromP = sFromP / UNITS_TO_GRAMS_SOLO_FACTOR;
        newValues = {
          units: uFromP.toFixed(2),
          solo: sFromP.toFixed(3),
          plastic: value,
        };
        break;
    }

    setValues(newValues);
  };

  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg border border-gray-200">
      <div className="space-y-6">
        <InputGroup
          label="Units"
          subLabel="(cc)"
          name={InputName.Units}
          value={values.units}
          onChange={handleInputChange}
          placeholder="e.g., 20"
        />
        <InputGroup
          label="Grams"
          subLabel="(base solo)"
          name={InputName.Solo}
          value={values.solo}
          onChange={handleInputChange}
          placeholder="e.g., 0.14"
        />
        <InputGroup
          label="Grams"
          subLabel="(with plastic)"
          name={InputName.Plastic}
          value={values.plastic}
          onChange={handleInputChange}
          placeholder="e.g., 0.46"
        />
      </div>
    </div>
  );
};

export default Calculator;
