import React from 'react';

const CosmicLogo: React.FC = () => (
  <svg width="60" height="60" viewBox="0 0 100 100" className="inline-block" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="45" fill="none" stroke="#2D2D2D" strokeWidth="6" />
    <path d="M20 50 C 40 20, 60 80, 80 50" fill="none" stroke="#2D2D2D" strokeWidth="6" strokeLinecap="round" />
  </svg>
);


const Header: React.FC = () => {
  return (
    <header className="text-center mb-8">
      <div className="flex items-center justify-center gap-2">
        <CosmicLogo />
        <h1 className="text-5xl font-bold tracking-tight text-[#2D2D2D]">
          Cosmic
        </h1>
      </div>
      <p className="text-lg text-gray-600 mt-2">Measurement Converter</p>
    </header>
  );
};

export default Header;
