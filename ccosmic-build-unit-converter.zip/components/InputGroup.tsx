import React from 'react';
import { InputName } from '../types';

interface InputGroupProps {
  label: string;
  subLabel: string;
  name: InputName;
  value: string;
  onChange: (name: InputName, value: string) => void;
  placeholder: string;
}

const InputGroup: React.FC<InputGroupProps> = ({ label, subLabel, name, value, onChange, placeholder }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange(name, e.target.value);
  };

  return (
    <div className="flex flex-col">
      <label htmlFor={name} className="mb-1 text-sm font-medium text-gray-500 flex items-baseline">
        {label} <span className="text-xs ml-1.5">{subLabel}</span>
      </label>
      <input
        id={name}
        name={name}
        type="number"
        value={value}
        onChange={handleChange}
        placeholder={placeholder}
        className="w-full px-4 py-3 bg-stone-50 border-2 border-stone-200 rounded-lg text-xl text-[#2D2D2D] focus:ring-2 focus:ring-amber-400 focus:border-amber-400 focus:outline-none transition-shadow duration-200"
        // Hide default number input spinners
        style={{ MozAppearance: 'textfield' }}
      />
    </div>
  );
};

export default InputGroup;
