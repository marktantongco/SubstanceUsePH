// Conversion factor from Units (cc) to Grams (base solo).
// Derived from the data: 10 units = 0.07g, so 1 unit = 0.007g.
export const UNITS_TO_GRAMS_SOLO_FACTOR = 0.007;

// The constant weight of the "plastic" in grams.
// Derived by finding the difference between "Grams with plastic" and "Grams base solo".
// e.g., 0.39g - 0.07g = 0.32g
export const PLASTIC_WEIGHT_GRAMS = 0.32;
