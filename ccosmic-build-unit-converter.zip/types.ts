/**
 * Enum to identify which input field is being changed.
 */
export enum InputName {
  Units = 'Units',
  Solo = 'Solo',
  Plastic = 'Plastic'
}

/**
 * Type definition for the state object that holds the string
 * values of the three converter inputs.
 */
export type ConversionState = {
  units: string;
  solo: string;
  plastic: string;
};
